// ═══════════════════════════════════════════════════
// KlasWerk — Dashboard Page
// ───────────────────────────────────────────────────
// Renders trainer or student view based on role.
// Full implementation in next session — this is the
// scaffold shell with stat card placeholders.
// ═══════════════════════════════════════════════════

import { useAuth } from '@/hooks/useAuth'
import { appConfig } from '@/config'

export function DashboardPage() {
  const { profile, isTrainer } = useAuth()

  return (
    <div className="kw-animate-fade-in">

      {/* Header */}
      <div style={{ marginBottom: '2rem' }}>
        <div className="kw-eyebrow" style={{ marginBottom: '0.5rem' }}>
          {appConfig.name} &nbsp;·&nbsp; {isTrainer ? 'Trainer' : 'Student'} Dashboard
        </div>
        <h1 style={{
          fontFamily: 'Cinzel, serif',
          fontSize: '1.6rem',
          fontWeight: 600,
          color: 'var(--kw-primary-lt)',
          marginBottom: '0.3rem',
        }}>
          Welcome back, {profile?.full_name?.split(' ')[0] || 'there'}
        </h1>
        <p style={{ color: 'var(--kw-muted)', fontFamily: 'Raleway, sans-serif', fontSize: '0.88rem' }}>
          {isTrainer
            ? 'Manage your courses, schedule live sessions, and track student progress.'
            : 'Pick up where you left off or explore new courses.'}
        </p>
      </div>

      {/* Stat cards */}
      <div style={{
        display: 'grid',
        gridTemplateColumns: 'repeat(auto-fill, minmax(200px, 1fr))',
        gap: '1rem',
        marginBottom: '2rem',
      }}>
        {(isTrainer ? TRAINER_STATS : STUDENT_STATS).map(stat => (
          <div key={stat.label} className="kw-card" style={{ padding: '1.2rem 1.4rem' }}>
            <div style={{
              fontFamily: 'Syne Mono, monospace',
              fontSize: '0.58rem',
              letterSpacing: '0.2em',
              textTransform: 'uppercase',
              color: 'var(--kw-primary-dk)',
              marginBottom: '0.5rem',
            }}>
              {stat.label}
            </div>
            <div style={{
              fontFamily: 'Cinzel, serif',
              fontSize: '2rem',
              fontWeight: 600,
              color: 'var(--kw-primary-lt)',
              lineHeight: 1,
            }}>
              {stat.value}
            </div>
            <div style={{ fontFamily: 'Raleway, sans-serif', fontSize: '0.72rem', color: 'var(--kw-muted)', marginTop: '0.3rem' }}>
              {stat.sub}
            </div>
          </div>
        ))}
      </div>

      {/* Placeholder content */}
      <div style={{
        background: 'var(--kw-surface)',
        border: '1px dashed var(--kw-border-lt)',
        borderRadius: '8px',
        padding: '3rem',
        textAlign: 'center',
        color: 'var(--kw-muted)',
        fontFamily: 'Cormorant Garamond, serif',
        fontStyle: 'italic',
        fontSize: '1rem',
      }}>
        ✦ &nbsp; Full dashboard content — courses, sessions, progress — builds in next session &nbsp; ✦
      </div>

    </div>
  )
}

const TRAINER_STATS = [
  { label: 'Active Courses',  value: '—', sub: 'Published courses' },
  { label: 'Total Students',  value: '—', sub: 'Enrolled across all courses' },
  { label: 'Live Sessions',   value: '—', sub: 'Scheduled this month' },
  { label: 'Completion Rate', value: '—', sub: 'Average across courses' },
]

const STUDENT_STATS = [
  { label: 'Enrolled',     value: '—', sub: 'Active courses' },
  { label: 'Completed',    value: '—', sub: 'Courses finished' },
  { label: 'Certificates', value: '—', sub: 'Earned' },
  { label: 'Quiz Average', value: '—', sub: 'Across all attempts' },
]
