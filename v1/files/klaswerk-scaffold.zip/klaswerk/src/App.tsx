// ═══════════════════════════════════════════════════
// KlasWerk — App Router
// ═══════════════════════════════════════════════════

import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom'
import { useAuth } from '@/hooks/useAuth'
import { ProtectedRoute } from '@/components/layout/ProtectedRoute'
import { AppShell } from '@/components/layout/AppShell'

// Pages
import { LoginPage }      from '@/pages/Login'
import { RegisterPage }   from '@/pages/Register'
import { CheckEmailPage } from '@/pages/CheckEmail'
import { DashboardPage }  from '@/pages/Dashboard'

// Placeholder stubs for pages built in future sessions
const Placeholder = ({ name }: { name: string }) => (
  <div style={{ padding: '2rem', color: 'var(--kw-muted)', fontFamily: 'Cormorant Garamond, serif', fontStyle: 'italic', fontSize: '1.1rem', textAlign: 'center' }}>
    ✦ &nbsp; {name} — coming in next session &nbsp; ✦
  </div>
)

// ── App root ─────────────────────────────────────────────────────────────────
export default function App() {
  // Boot the auth listener — runs once at app root
  useAuth()

  return (
    <BrowserRouter>
      <Routes>

        {/* ── Public routes ── */}
        <Route path="/login"       element={<LoginPage />} />
        <Route path="/register"    element={<RegisterPage />} />
        <Route path="/check-email" element={<CheckEmailPage />} />

        {/* Certificate verification — public, no auth needed */}
        <Route path="/verify/:certificateNumber" element={<Placeholder name="Certificate Verification" />} />

        {/* ── Protected routes — any authenticated user ── */}
        <Route path="/dashboard" element={
          <ProtectedRoute>
            <AppShell><DashboardPage /></AppShell>
          </ProtectedRoute>
        } />

        <Route path="/courses" element={
          <ProtectedRoute>
            <AppShell><Placeholder name="Courses" /></AppShell>
          </ProtectedRoute>
        } />

        <Route path="/courses/:courseId" element={
          <ProtectedRoute>
            <AppShell><Placeholder name="Course Detail" /></AppShell>
          </ProtectedRoute>
        } />

        <Route path="/live" element={
          <ProtectedRoute>
            <AppShell><Placeholder name="Live Sessions" /></AppShell>
          </ProtectedRoute>
        } />

        <Route path="/live/:sessionId" element={
          <ProtectedRoute>
            <AppShell><Placeholder name="Live Session Room" /></AppShell>
          </ProtectedRoute>
        } />

        <Route path="/quizzes" element={
          <ProtectedRoute>
            <AppShell><Placeholder name="Quizzes" /></AppShell>
          </ProtectedRoute>
        } />

        <Route path="/quizzes/:quizId" element={
          <ProtectedRoute>
            <AppShell><Placeholder name="Quiz" /></AppShell>
          </ProtectedRoute>
        } />

        <Route path="/certificates" element={
          <ProtectedRoute>
            <AppShell><Placeholder name="Certificates" /></AppShell>
          </ProtectedRoute>
        } />

        <Route path="/profile" element={
          <ProtectedRoute>
            <AppShell><Placeholder name="Profile" /></AppShell>
          </ProtectedRoute>
        } />

        {/* ── Trainer-only routes ── */}
        <Route path="/analytics" element={
          <ProtectedRoute requiredRole="trainer">
            <AppShell><Placeholder name="Analytics Dashboard" /></AppShell>
          </ProtectedRoute>
        } />

        <Route path="/courses/new" element={
          <ProtectedRoute requiredRole="trainer">
            <AppShell><Placeholder name="Create Course" /></AppShell>
          </ProtectedRoute>
        } />

        <Route path="/payment/return"  element={<Placeholder name="Payment Return" />} />
        <Route path="/payment/cancel"  element={<Placeholder name="Payment Cancelled" />} />

        {/* ── Default redirect ── */}
        <Route path="/" element={<Navigate to="/dashboard" replace />} />
        <Route path="*" element={<Navigate to="/dashboard" replace />} />

      </Routes>
    </BrowserRouter>
  )
}
